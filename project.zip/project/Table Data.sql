select * from Users
select * from Trains

select * from Reservations
select * from Trains
select * from Users